
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const fetchHorseWisdom = async (score: number): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `The player just finished a game of 'Horse Snake' with a score of ${score}. 
      Give them a short, punny, motivational message from a professional jockey or a wise horse. 
      Keep it under 15 words and full of horse energy.`,
      config: {
        temperature: 0.8,
        topP: 0.95,
      }
    });
    return response.text?.trim() || "Hay there! You galloped well!";
  } catch (error) {
    console.error("Failed to fetch horse wisdom:", error);
    return "Keep trotting, champion! Every long journey starts with a single hoofbeat.";
  }
};
