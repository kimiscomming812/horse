
import React from 'react';
import { Direction } from '../types';

interface ControlsProps {
  onDirectionChange: (dir: Direction) => void;
  status: string;
}

const Controls: React.FC<ControlsProps> = ({ onDirectionChange, status }) => {
  return (
    <div className="mt-8 grid grid-cols-3 gap-2 w-full max-w-[200px] mx-auto">
      <div />
      <button 
        className="h-14 bg-stone-700 active:bg-stone-600 rounded-xl shadow-lg flex items-center justify-center text-xl transition-transform active:scale-95"
        onClick={() => onDirectionChange(Direction.UP)}
      >
        <i className="fa-solid fa-chevron-up"></i>
      </button>
      <div />
      
      <button 
        className="h-14 bg-stone-700 active:bg-stone-600 rounded-xl shadow-lg flex items-center justify-center text-xl transition-transform active:scale-95"
        onClick={() => onDirectionChange(Direction.LEFT)}
      >
        <i className="fa-solid fa-chevron-left"></i>
      </button>
      <button 
        className="h-14 bg-stone-700 active:bg-stone-600 rounded-xl shadow-lg flex items-center justify-center text-xl transition-transform active:scale-95"
        onClick={() => onDirectionChange(Direction.DOWN)}
      >
        <i className="fa-solid fa-chevron-down"></i>
      </button>
      <button 
        className="h-14 bg-stone-700 active:bg-stone-600 rounded-xl shadow-lg flex items-center justify-center text-xl transition-transform active:scale-95"
        onClick={() => onDirectionChange(Direction.RIGHT)}
      >
        <i className="fa-solid fa-chevron-right"></i>
      </button>
    </div>
  );
};

export default Controls;
