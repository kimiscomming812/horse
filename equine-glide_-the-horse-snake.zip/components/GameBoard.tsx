
import React from 'react';
import { Point, GameStatus } from '../types';
import { GRID_SIZE } from '../constants';

interface GameBoardProps {
  snake: Point[];
  food: Point;
  obstacles: Point[];
  status: GameStatus;
}

const GameBoard: React.FC<GameBoardProps> = ({ snake, food, obstacles, status }) => {
  const renderCell = (x: number, y: number) => {
    const isFood = food.x === x && food.y === y;
    const isHead = snake[0].x === x && snake[0].y === y;
    const isBody = snake.some((segment, index) => index !== 0 && segment.x === x && segment.y === y);
    const isObstacle = obstacles.some(obs => obs.x === x && obs.y === y);

    let content = null;
    let className = "w-full h-full border-[0.5px] border-[#8bac0f]/30 flex items-center justify-center";

    if (isHead) {
      // 领头的马头
      content = <span className="text-xs md:text-sm drop-shadow-sm">🐴</span>;
      className += " z-10 scale-125";
    } else if (isBody) {
      // 随行的小马，不再使用方块背景
      content = <span className="text-[10px] md:text-xs opacity-90 drop-shadow-sm">🐎</span>;
      className += " z-0";
    } else if (isFood) {
      content = <span className="text-xs">🥕</span>;
      className += " animate-pulse";
    } else if (isObstacle) {
      content = <span className="text-xs">🪵</span>;
      className += " bg-[#0f380f]/40";
    }

    return (
      <div 
        key={`${x}-${y}`} 
        className={className}
        style={{ gridColumnStart: x + 1, gridRowStart: y + 1 }}
      >
        {content}
      </div>
    );
  };

  const cells = [];
  for (let y = 0; y < GRID_SIZE; y++) {
    for (let x = 0; x < GRID_SIZE; x++) {
      cells.push(renderCell(x, y));
    }
  }

  return (
    <div className="relative aspect-square w-full max-w-[400px] mx-auto border-8 border-stone-800 rounded-lg overflow-hidden nokia-screen">
      <div 
        className="grid w-full h-full" 
        style={{ 
          gridTemplateColumns: `repeat(${GRID_SIZE}, 1fr)`,
          gridTemplateRows: `repeat(${GRID_SIZE}, 1fr)`
        }}
      >
        {cells}
      </div>
      
      {/* Overlay for specific states */}
      {status === GameStatus.PAUSED && (
        <div className="absolute inset-0 bg-black/20 backdrop-blur-sm flex items-center justify-center z-30">
          <span className="text-stone-900 text-4xl retro-font font-bold">PAUSED</span>
        </div>
      )}

      {/* Screen Effects */}
      <div className="absolute inset-0 scanlines opacity-30 z-20 pointer-events-none"></div>
    </div>
  );
};

export default GameBoard;
